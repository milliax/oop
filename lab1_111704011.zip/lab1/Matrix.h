#ifndef __MATRIX_H__
#define __MATRIX_H__

class Matrix {
   public:
    int m_matrix[3][3];

    Matrix() : m_matrix{{0}} {}
    Matrix(int a, int b, int c, int d, int e, int f, int g, int h, int i)
        : m_matrix{{a, b, c}, {d, e, f}, {g, h, i}} {}

	void read();
    void print();
    void add(Matrix m);
    void multiple(Matrix m);
    void transpose();
};

#endif  // __MATRIX_H__