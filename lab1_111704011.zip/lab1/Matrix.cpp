#include "Matrix.h"

#include <iostream>

void Matrix::read() {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            std::cin >> m_matrix[i][j];
        }
    }
}

void Matrix::print() {
    bool first_time = true;

    std::cout << "[";

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (!first_time) {
                std::cout << ", " << m_matrix[i][j];
            } else {
                first_time = false;
                std::cout << m_matrix[i][j];
            }
        }
    }
    std::cout << "]" << std::endl;
}

void Matrix::add(Matrix m) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            m_matrix[i][j] += m.m_matrix[i][j];
        }
    }
}

void Matrix::multiple(Matrix m) {
    int tem[3][3];
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            tem[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                tem[i][j] += m_matrix[i][k] * m.m_matrix[k][j];
            }
        }
    }
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            m_matrix[i][j] = tem[i][j];
        }
    }
}

void Matrix::transpose() {
    Matrix temp;

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            temp.m_matrix[i][j] = m_matrix[j][i];
        }
    }

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            m_matrix[i][j] = temp.m_matrix[i][j];
        }
    }
}