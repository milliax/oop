#include <iostream>

#include "Matrix.h"

using namespace std;

int main() {
    int n;
    cin >> n;

    while (n--) {
        char command;
        cin >> command;

        Matrix m1, m2;

        switch (command) {
            case '+':
				m1.read();
				m2.read();

				m1.add(m2);
				m1.print();

                break;
            case '*':
				m1.read();
				m2.read();

				m1.multiple(m2);
				m1.print();
                break;
            case 'p':
				m1.read();
				m1.print();
                break;
            case 't':
				m1.read();
				m1.transpose();
				m1.print();

                break;
            default:
                cout << "wrong input!" << endl;
                break;
        }
    }

    return 0;
}